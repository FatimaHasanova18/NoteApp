package com.example.notes

import java.io.Serializable

class Note(val id :Int ,val headname:String,val textabout:String):Serializable {

}