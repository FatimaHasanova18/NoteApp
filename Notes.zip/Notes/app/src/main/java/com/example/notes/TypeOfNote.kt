package com.example.notes

import java.io.Serializable

class TypeOfNote(val type:String):Serializable {
}