package com.example.notes

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.notes.databinding.ActivityNoteBinding

class NoteActivity : AppCompatActivity() {
    private lateinit var binding: ActivityNoteBinding
    private lateinit var myDatabase: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)
        enableEdgeToEdge()

        val selectedItem = intent.getSerializableExtra("Note") as? Note
        if (selectedItem != null) {
            binding.headText.setText(selectedItem.headname)
            binding.Text.setText(selectedItem.textabout)
        }

        binding.arrow.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        binding.savebtn.setOnClickListener {
            if (binding.headText.text.isNotEmpty() && binding.Text.text.isNotEmpty()) {
                updateNoteInDatabase(binding.headText.text.toString(), binding.Text.text.toString())
                binding.savebtn.text = "Update"
            } else {
                saveNoteToDatabase()
                binding.savebtn.text = "Save"
            }
            binding.savebtn.visibility = View.VISIBLE
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun saveNoteToDatabase() {
        val title = binding.headText.text.toString()
        val text = binding.Text.text.toString()
        try {
            myDatabase = openOrCreateDatabase("Notes", Context.MODE_PRIVATE, null)
            myDatabase.execSQL("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, head TEXT, content TEXT)")
            val contentValues = ContentValues()
            contentValues.put("head", title)
            contentValues.put("content", text)
            myDatabase.insert("notes", null, contentValues)
            Toast.makeText(this, "Note saved successfully", Toast.LENGTH_SHORT).show()
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
    }

    private fun updateNoteInDatabase(newHead: String, newContent: String) {
        try {
            myDatabase = openOrCreateDatabase("Notes", Context.MODE_PRIVATE, null)
            val updateQuery = "UPDATE notes SET content = ? WHERE head = ?"
            val statement = myDatabase.compileStatement(updateQuery)
            statement.bindString(1, newHead)
            statement.bindString(2, newContent)
            statement.executeUpdateDelete()
            myDatabase.close()
            Toast.makeText(this, "Note updated successfully", Toast.LENGTH_SHORT).show()
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
    }
}
