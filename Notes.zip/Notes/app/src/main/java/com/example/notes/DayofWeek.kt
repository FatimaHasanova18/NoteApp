package com.example.notes

import java.io.Serializable

class DayofWeek(val week:String,val day:String,val month:String):Serializable {

}