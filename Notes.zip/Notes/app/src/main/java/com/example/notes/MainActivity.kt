package com.example.notes

import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.notes.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var dayList: ArrayList<DayofWeek>
    private lateinit var typeList: ArrayList<TypeOfNote>
    private lateinit var noteList: ArrayList<Note>
    private lateinit var database: SQLiteDatabase
    private lateinit var noteAdapter: NoteAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        enableEdgeToEdge()

        binding.btnlar.setOnClickListener {
            val intent = Intent(this@MainActivity, NoteActivity::class.java)
            startActivity(intent)
        }
        setupRecycler()
    }

    private fun setupRecycler() {
        dayList = ArrayList<DayofWeek>()
        dayList.add(DayofWeek("Tue", "23", "Apr"))
        dayList.add(DayofWeek("Wed", "24", "Apr"))
        dayList.add(DayofWeek("Thu", "25", "Apr"))
        dayList.add(DayofWeek("Fri", "26", "Apr"))
        dayList.add(DayofWeek("Sat", "27", "Apr"))
        dayList.add(DayofWeek("Sun", "28", "Apr"))
        dayList.add(DayofWeek("Mon", "29", "Apr"))
        val layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerDay.layoutManager = layoutManager
        val adapter = DayAdapter(dayList)
        binding.recyclerDay.adapter = adapter

        typeList = ArrayList<TypeOfNote>()
        val type1 = TypeOfNote("All")
        val type2 = TypeOfNote("Important")
        val type3 = TypeOfNote("Lecture notes")
        val type4 = TypeOfNote("To-do lists")
        val type5 = TypeOfNote("Shopping")
        typeList.add(type1)
        typeList.add(type2)
        typeList.add(type3)
        typeList.add(type4)
        typeList.add(type5)
        val layoutManager2 = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerTime.layoutManager = layoutManager2
        val adapter2 = TypeAdapter(typeList)
        binding.recyclerTime.adapter = adapter2

        noteList = ArrayList<Note>()
        loadNotesFromDatabase()
        noteAdapter = NoteAdapter(noteList)
        binding.recyclernote.layoutManager = LinearLayoutManager(this)
        binding.recyclernote.adapter = noteAdapter
    }

    private fun loadNotesFromDatabase() {
        try {
            database = openOrCreateDatabase("Notes", Context.MODE_PRIVATE, null)
            database.execSQL("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, head TEXT, content TEXT)")
            val cursor = database.rawQuery("SELECT * FROM notes", null)
            val idIx = cursor.getColumnIndex("id")
            val headIx = cursor.getColumnIndex("head")
            val contentIx = cursor.getColumnIndex("content")

            noteList.clear()
            while (cursor.moveToNext()) {
                val id = cursor.getInt(idIx)
                val headname = cursor.getString(headIx)
                val textabout = cursor.getString(contentIx)
                val note = Note(id, headname, textabout)
                noteList.add(note)
            }
            cursor.close()
            noteAdapter.notifyDataSetChanged()
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
    }
}
