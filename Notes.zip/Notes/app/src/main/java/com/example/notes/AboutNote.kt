package com.example.notes

import java.io.Serializable

class AboutNote(val headname:String,val textabout:String):Serializable {
}